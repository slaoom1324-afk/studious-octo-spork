package dev.md5n.util;

import net.minecraft.client.gui.DrawContext;

public final class Draw {
    private Draw() {}

    public static int alpha(int color, float f) {
        int a = (int) (((color >>> 24) & 0xFF) * Math.max(0f, Math.min(1f, f)));
        return (a << 24) | (color & 0x00FFFFFF);
    }

    /** مستطيل بزوايا مدورة (تقريب بخطوط أفقية). */
    public static void roundRect(DrawContext ctx, int x1, int y1, int x2, int y2, int r, int color) {
        r = Math.max(0, Math.min(r, Math.min((x2 - x1) / 2, (y2 - y1) / 2)));
        if (r == 0) {
            ctx.fill(x1, y1, x2, y2, color);
            return;
        }
        ctx.fill(x1, y1 + r, x2, y2 - r, color);
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            int dx = r - (int) Math.round(Math.sqrt(Math.max(0.0, (double) r * r - dy * dy)));
            ctx.fill(x1 + dx, y1 + i, x2 - dx, y1 + i + 1, color);
            ctx.fill(x1 + dx, y2 - i - 1, x2 - dx, y2 - i, color);
        }
    }

    /** لوحة زجاجية: توهج خفيف + إطار + تعبئة شبه شفافة. الألوان تمرّ جاهزة (مع الشفافية). */
    public static void glass(DrawContext ctx, int x1, int y1, int x2, int y2, int r, int fill, int border, int glow) {
        for (int i = 3; i >= 1; i--) {
            roundRect(ctx, x1 - i, y1 - i, x2 + i, y2 + i, r + i, glow);
        }
        roundRect(ctx, x1, y1, x2, y2, r, border);
        roundRect(ctx, x1 + 1, y1 + 1, x2 - 1, y2 - 1, Math.max(0, r - 1), fill);
    }
}
