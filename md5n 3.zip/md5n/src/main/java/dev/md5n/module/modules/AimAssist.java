package dev.md5n.module.modules;

import dev.md5n.module.Category;
import dev.md5n.module.Module;
import dev.md5n.setting.BoolSetting;
import dev.md5n.setting.NumSetting;
import dev.md5n.util.Targets;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public class AimAssist extends Module {
    private final NumSetting range = num("Range", 4.5, 1, 6, 0.1, "Max distance to a target");
    private final NumSetting fov = num("FOV", 90, 10, 360, 5, "Only assist targets inside this angle");
    private final NumSetting smooth = num("Smooth", 0.15, 0.01, 1.0, 0.01, "Lower = slower, softer pull");
    private final NumSetting maxStep = num("Max Step", 8, 1, 30, 1, "Max degrees turned per tick");
    private final BoolSetting onlyAttacking = bool("Only While Attacking", true, "Only assist while holding attack");
    private final BoolSetting visibleOnly = bool("Visible Only", true, "Ignore targets behind walls");
    private final BoolSetting players = bool("Players", true, "Assist on players");
    private final BoolSetting hostile = bool("Hostile", true, "Assist on hostile mobs");
    private final BoolSetting passive = bool("Passive", false, "Assist on animals and villagers");

    public AimAssist() {
        super("AimAssist", Category.COMBAT, "Smoothly nudges your aim toward nearby targets");
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.currentScreen != null) return;
        if (onlyAttacking.get() && !mc.options.attackKey.isPressed()) return;

        LivingEntity target = findTarget();
        if (target == null) return;

        Vec3d eye = mc.player.getEyePos();
        Vec3d aim = target.getPos().add(0, target.getHeight() * 0.85, 0);

        double dx = aim.x - eye.x;
        double dy = aim.y - eye.y;
        double dz = aim.z - eye.z;
        double horizontal = Math.sqrt(dx * dx + dz * dz);

        float targetYaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float targetPitch = (float) -Math.toDegrees(Math.atan2(dy, horizontal));

        float yawDiff = MathHelper.wrapDegrees(targetYaw - mc.player.getYaw());
        float pitchDiff = targetPitch - mc.player.getPitch();

        if (Math.abs(yawDiff) > fov.getFloat() / 2f) return;

        float step = maxStep.getFloat();
        float yawStep = MathHelper.clamp(yawDiff * smooth.getFloat(), -step, step);
        float pitchStep = MathHelper.clamp(pitchDiff * smooth.getFloat(), -step, step);

        mc.player.setYaw(mc.player.getYaw() + yawStep);
        mc.player.setPitch(MathHelper.clamp(mc.player.getPitch() + pitchStep, -90f, 90f));
    }

    private LivingEntity findTarget() {
        LivingEntity best = null;
        double bestDist = Double.MAX_VALUE;

        for (Entity e : mc.world.getEntities()) {
            if (!Targets.valid(e, players.get(), hostile.get(), passive.get())) continue;
            LivingEntity living = (LivingEntity) e;
            if (living.isInvisible()) continue;

            double dist = mc.player.distanceTo(living);
            if (dist > range.get() || dist >= bestDist) continue;
            if (visibleOnly.get() && !mc.player.canSee(living)) continue;

            best = living;
            bestDist = dist;
        }
        return best;
    }
}
