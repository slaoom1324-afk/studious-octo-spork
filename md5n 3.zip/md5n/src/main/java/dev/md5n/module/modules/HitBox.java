package dev.md5n.module.modules;

import dev.md5n.module.Category;
import dev.md5n.module.Module;
import dev.md5n.setting.BoolSetting;
import dev.md5n.setting.NumSetting;
import dev.md5n.util.Targets;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.util.math.Box;

public class HitBox extends Module {
    private final NumSetting expand = num("Expand", 0.15, 0.0, 0.5, 0.05, "How much bigger the hitbox gets");
    private final BoolSetting show = bool("Show Hitbox", true, "Draw hitboxes while the module is on");
    private final BoolSetting players = bool("Players", true, "Expand player hitboxes");
    private final BoolSetting hostile = bool("Hostile", true, "Expand hostile mob hitboxes");
    private final BoolSetting passive = bool("Passive", false, "Expand animals and villagers");

    private boolean hadHitboxes;

    public HitBox() {
        super("HitBox", Category.COMBAT, "Bigger, visible hitboxes that are easier to hit");
    }

    @Override
    protected void onEnable() {
        if (mc.getEntityRenderDispatcher() != null) {
            hadHitboxes = mc.getEntityRenderDispatcher().shouldRenderHitboxes();
        }
    }

    @Override
    public void onTick() {
        if (mc.world == null) return;
        float margin = expand.getFloat();

        for (Entity e : mc.world.getEntities()) {
            if (e == mc.player || !(e instanceof LivingEntity) || e instanceof ArmorStandEntity) continue;
            boolean target = Targets.valid(e, players.get(), hostile.get(), passive.get());
            Box base = e.getDimensions(e.getPose()).getBoxAt(e.getPos());
            e.setBoundingBox(target ? base.expand(margin) : base);
        }

        if (mc.getEntityRenderDispatcher() != null) {
            mc.getEntityRenderDispatcher().setRenderHitboxes(show.get());
        }
    }

    @Override
    protected void onDisable() {
        if (mc.world != null) {
            for (Entity e : mc.world.getEntities()) {
                if (e == mc.player || !(e instanceof LivingEntity) || e instanceof ArmorStandEntity) continue;
                e.setBoundingBox(e.getDimensions(e.getPose()).getBoxAt(e.getPos()));
            }
        }
        if (mc.getEntityRenderDispatcher() != null) {
            mc.getEntityRenderDispatcher().setRenderHitboxes(hadHitboxes);
        }
    }
}
