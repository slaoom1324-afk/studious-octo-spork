package dev.md5n.util;

import dev.md5n.Md5n;
import dev.md5n.module.modules.ThemeSettings;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.sound.SoundEvents;

public final class Sfx {
    private Sfx() {}

    private static void play(float pitch) {
        if (Md5n.modules == null) return;
        ThemeSettings theme = Md5n.modules.get(ThemeSettings.class);
        if (theme != null && !theme.sounds()) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.getSoundManager() == null) return;
        mc.getSoundManager().play(PositionedSoundInstance.master(SoundEvents.UI_BUTTON_CLICK, pitch));
    }

    public static void open() { play(1.6f); }
    public static void close() { play(1.0f); }
    public static void on() { play(1.35f); }
    public static void off() { play(0.8f); }
    public static void click() { play(1.15f); }
}
