package dev.md5n.module.modules;

import dev.md5n.module.Category;
import dev.md5n.module.Module;
import dev.md5n.setting.NumSetting;
import net.minecraft.entity.player.PlayerAbilities;

public class Flight extends Module {
    private static final float DEFAULT_SPEED = 0.05f;

    private final NumSetting speed = num("Speed", 0.10, 0.02, 0.50, 0.01, "Flight speed (vanilla creative is 0.05)");

    public Flight() {
        super("Flight", Category.MOVEMENT, "Creative-style flight (double-tap space)");
    }

    @Override
    public void onTick() {
        if (mc.player == null) return;
        PlayerAbilities abilities = mc.player.getAbilities();
        abilities.allowFlying = true;
        abilities.setFlySpeed(speed.getFloat());
    }

    @Override
    protected void onDisable() {
        if (mc.player == null) return;
        PlayerAbilities abilities = mc.player.getAbilities();
        boolean creative = mc.player.isCreative() || mc.player.isSpectator();
        abilities.setFlySpeed(DEFAULT_SPEED);
        abilities.allowFlying = creative;
        if (!creative) abilities.flying = false;
    }
}
